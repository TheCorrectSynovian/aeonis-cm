@NullMarked
package com.mojang.math;

import org.jspecify.annotations.NullMarked;
