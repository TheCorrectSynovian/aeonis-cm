package net.minecraft.world.entity;

public interface ItemSteerable {
	boolean boost();
}
