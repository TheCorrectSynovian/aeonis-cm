package net.minecraft.world.entity.animal;

public interface FlyingAnimal {
	boolean isFlying();
}
