@NullMarked
package net.minecraft.world.entity.animal.camel;

import org.jspecify.annotations.NullMarked;
