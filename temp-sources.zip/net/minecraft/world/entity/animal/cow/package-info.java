@NullMarked
package net.minecraft.world.entity.animal.cow;

import org.jspecify.annotations.NullMarked;
