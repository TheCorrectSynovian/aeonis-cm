@NullMarked
package net.minecraft.world.entity.animal.chicken;

import org.jspecify.annotations.NullMarked;
