@NullMarked
package net.minecraft.world.entity.animal.armadillo;

import org.jspecify.annotations.NullMarked;
