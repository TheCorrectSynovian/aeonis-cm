@NullMarked
package net.minecraft.world.entity.animal.allay;

import org.jspecify.annotations.NullMarked;
