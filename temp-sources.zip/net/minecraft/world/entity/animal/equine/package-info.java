@NullMarked
package net.minecraft.world.entity.animal.equine;

import org.jspecify.annotations.NullMarked;
