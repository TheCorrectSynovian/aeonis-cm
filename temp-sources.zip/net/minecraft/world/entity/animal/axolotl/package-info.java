@NullMarked
package net.minecraft.world.entity.animal.axolotl;

import org.jspecify.annotations.NullMarked;
