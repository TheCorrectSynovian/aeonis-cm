@NullMarked
package net.minecraft.world.entity.animal.bee;

import org.jspecify.annotations.NullMarked;
