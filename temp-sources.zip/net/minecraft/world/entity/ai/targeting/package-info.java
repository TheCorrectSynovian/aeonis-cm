@NullMarked
package net.minecraft.world.entity.ai.targeting;

import org.jspecify.annotations.NullMarked;
