@NullMarked
package net.minecraft.world.entity.ai.attributes;

import org.jspecify.annotations.NullMarked;
