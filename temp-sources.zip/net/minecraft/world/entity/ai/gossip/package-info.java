@NullMarked
package net.minecraft.world.entity.ai.gossip;

import org.jspecify.annotations.NullMarked;
