@NullMarked
package net.minecraft.world.entity.ai.util;

import org.jspecify.annotations.NullMarked;
