@NullMarked
package net.minecraft.world.entity.ai.sensing;

import org.jspecify.annotations.NullMarked;
