@NullMarked
package net.minecraft.world.entity.ai.behavior;

import org.jspecify.annotations.NullMarked;
