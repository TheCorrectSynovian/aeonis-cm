@NullMarked
package net.minecraft.world.entity.ai.navigation;

import org.jspecify.annotations.NullMarked;
