@NullMarked
package net.minecraft.world.entity.ai.memory;

import org.jspecify.annotations.NullMarked;
