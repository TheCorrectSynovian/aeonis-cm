package net.minecraft.world.entity.ai.memory;

public enum MemoryStatus {
	VALUE_PRESENT,
	VALUE_ABSENT,
	REGISTERED;
}
