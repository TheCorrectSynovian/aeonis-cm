package net.minecraft.world.entity.ai.goal;

enum BoatGoals {
	GO_TO_BOAT,
	GO_IN_BOAT_DIRECTION;
}
