@NullMarked
package net.minecraft.world.entity.ai.goal;

import org.jspecify.annotations.NullMarked;
