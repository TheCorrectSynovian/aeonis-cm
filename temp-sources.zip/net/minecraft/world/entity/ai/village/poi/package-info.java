@NullMarked
package net.minecraft.world.entity.ai.village.poi;

import org.jspecify.annotations.NullMarked;
