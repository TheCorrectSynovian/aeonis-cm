@NullMarked
package net.minecraft.world.entity.ai;

import org.jspecify.annotations.NullMarked;
