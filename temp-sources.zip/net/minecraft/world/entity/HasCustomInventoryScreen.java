package net.minecraft.world.entity;

import net.minecraft.world.entity.player.Player;

public interface HasCustomInventoryScreen {
	void openCustomInventoryScreen(Player player);
}
