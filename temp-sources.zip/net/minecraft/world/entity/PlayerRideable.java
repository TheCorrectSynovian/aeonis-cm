package net.minecraft.world.entity;

public interface PlayerRideable {
}
