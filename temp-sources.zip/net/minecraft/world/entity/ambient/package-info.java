@NullMarked
package net.minecraft.world.entity.ambient;

import org.jspecify.annotations.NullMarked;
