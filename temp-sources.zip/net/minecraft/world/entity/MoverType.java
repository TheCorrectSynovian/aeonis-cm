package net.minecraft.world.entity;

public enum MoverType {
	SELF,
	PLAYER,
	PISTON,
	SHULKER_BOX,
	SHULKER;
}
