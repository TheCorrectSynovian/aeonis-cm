package net.minecraft.world;

public interface ContainerListener {
	void containerChanged(Container container);
}
