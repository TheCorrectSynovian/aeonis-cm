@NullMarked
package net.minecraft.world.attribute.modifier;

import org.jspecify.annotations.NullMarked;
