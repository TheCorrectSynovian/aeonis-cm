@NullMarked
package net.minecraft.world.attribute;

import org.jspecify.annotations.NullMarked;
