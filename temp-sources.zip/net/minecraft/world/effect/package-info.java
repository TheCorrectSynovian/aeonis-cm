@NullMarked
package net.minecraft.world.effect;

import org.jspecify.annotations.NullMarked;
