package net.minecraft.world;

public interface Clearable {
	void clearContent();
}
