@NullMarked
package net.minecraft.world.damagesource;

import org.jspecify.annotations.NullMarked;
