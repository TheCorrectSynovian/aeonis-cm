@NullMarked
package net.minecraft.util.worldupdate;

import org.jspecify.annotations.NullMarked;
