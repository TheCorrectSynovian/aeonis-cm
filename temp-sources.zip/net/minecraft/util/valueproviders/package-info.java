@NullMarked
package net.minecraft.util.valueproviders;

import org.jspecify.annotations.NullMarked;
