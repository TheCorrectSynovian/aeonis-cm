@NullMarked
@Environment(EnvType.CLIENT)
package net.minecraft.client.gui.contextualbar;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.NullMarked;
