@NullMarked
@Environment(EnvType.CLIENT)
package net.minecraft.client.gui.font;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.NullMarked;
