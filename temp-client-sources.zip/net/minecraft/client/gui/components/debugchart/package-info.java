@NullMarked
@Environment(EnvType.CLIENT)
package net.minecraft.client.gui.components.debugchart;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.NullMarked;
