package net.minecraft.client;

import com.google.common.collect.ImmutableList;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleFunction;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntFunction;
import java.util.stream.IntStream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractOptionSliderButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.ResettableOptionWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

@Environment(EnvType.CLIENT)
public final class OptionInstance<T> {
	private static final Logger LOGGER = LogUtils.getLogger();
	public static final OptionInstance.Enum<Boolean> BOOLEAN_VALUES = new OptionInstance.Enum<>(ImmutableList.of(Boolean.TRUE, Boolean.FALSE), Codec.BOOL);
	public static final OptionInstance.CaptionBasedToString<Boolean> BOOLEAN_TO_STRING = (component, boolean_) -> boolean_
		? CommonComponents.OPTION_ON
		: CommonComponents.OPTION_OFF;
	private final OptionInstance.TooltipSupplier<T> tooltip;
	final Function<T, Component> toString;
	private final OptionInstance.ValueSet<T> values;
	private final Codec<T> codec;
	private final T initialValue;
	private final Consumer<T> onValueUpdate;
	final Component caption;
	private T value;

	public static OptionInstance<Boolean> createBoolean(String string, boolean bl, Consumer<Boolean> consumer) {
		return createBoolean(string, noTooltip(), bl, consumer);
	}

	public static OptionInstance<Boolean> createBoolean(String string, boolean bl) {
		return createBoolean(string, noTooltip(), bl, boolean_ -> {});
	}

	public static OptionInstance<Boolean> createBoolean(String string, OptionInstance.TooltipSupplier<Boolean> tooltipSupplier, boolean bl) {
		return createBoolean(string, tooltipSupplier, bl, boolean_ -> {});
	}

	public static OptionInstance<Boolean> createBoolean(
		String string, OptionInstance.TooltipSupplier<Boolean> tooltipSupplier, boolean bl, Consumer<Boolean> consumer
	) {
		return createBoolean(string, tooltipSupplier, BOOLEAN_TO_STRING, bl, consumer);
	}

	public static OptionInstance<Boolean> createBoolean(
		String string,
		OptionInstance.TooltipSupplier<Boolean> tooltipSupplier,
		OptionInstance.CaptionBasedToString<Boolean> captionBasedToString,
		boolean bl,
		Consumer<Boolean> consumer
	) {
		return new OptionInstance<>(string, tooltipSupplier, captionBasedToString, BOOLEAN_VALUES, bl, consumer);
	}

	public OptionInstance(
		String string,
		OptionInstance.TooltipSupplier<T> tooltipSupplier,
		OptionInstance.CaptionBasedToString<T> captionBasedToString,
		OptionInstance.ValueSet<T> valueSet,
		T object,
		Consumer<T> consumer
	) {
		this(string, tooltipSupplier, captionBasedToString, valueSet, valueSet.codec(), object, consumer);
	}

	public OptionInstance(
		String string,
		OptionInstance.TooltipSupplier<T> tooltipSupplier,
		OptionInstance.CaptionBasedToString<T> captionBasedToString,
		OptionInstance.ValueSet<T> valueSet,
		Codec<T> codec,
		T object,
		Consumer<T> consumer
	) {
		this.caption = Component.translatable(string);
		this.tooltip = tooltipSupplier;
		this.toString = objectx -> captionBasedToString.toString(this.caption, (T)objectx);
		this.values = valueSet;
		this.codec = codec;
		this.initialValue = object;
		this.onValueUpdate = consumer;
		this.value = this.initialValue;
	}

	public static <T> OptionInstance.TooltipSupplier<T> noTooltip() {
		return object -> null;
	}

	public static <T> OptionInstance.TooltipSupplier<T> cachedConstantTooltip(Component component) {
		return object -> Tooltip.create(component);
	}

	public AbstractWidget createButton(Options options) {
		return this.createButton(options, 0, 0, 150);
	}

	public AbstractWidget createButton(Options options, int i, int j, int k) {
		return this.createButton(options, i, j, k, object -> {});
	}

	public AbstractWidget createButton(Options options, int i, int j, int k, Consumer<T> consumer) {
		return (AbstractWidget)this.values.createButton(this.tooltip, options, i, j, k, consumer).apply(this);
	}

	public T get() {
		return this.value;
	}

	public Codec<T> codec() {
		return this.codec;
	}

	public String toString() {
		return this.caption.getString();
	}

	public void set(T object) {
		T object2 = (T)this.values.validateValue(object).orElseGet(() -> {
			LOGGER.error("Illegal option value {} for {}", object, this.caption.getString());
			return this.initialValue;
		});
		if (!Minecraft.getInstance().isRunning()) {
			this.value = object2;
		} else {
			if (!Objects.equals(this.value, object2)) {
				this.value = object2;
				this.onValueUpdate.accept(this.value);
			}
		}
	}

	public OptionInstance.ValueSet<T> values() {
		return this.values;
	}

	@Environment(EnvType.CLIENT)
	public record AltEnum<T>(
		List<T> values, List<T> altValues, BooleanSupplier altCondition, OptionInstance.CycleableValueSet.ValueSetter<T> valueSetter, Codec<T> codec
	) implements OptionInstance.CycleableValueSet<T> {
		@Override
		public CycleButton.ValueListSupplier<T> valueListSupplier() {
			return CycleButton.ValueListSupplier.create(this.altCondition, this.values, this.altValues);
		}

		@Override
		public Optional<T> validateValue(T object) {
			return (this.altCondition.getAsBoolean() ? this.altValues : this.values).contains(object) ? Optional.of(object) : Optional.empty();
		}
	}

	@Environment(EnvType.CLIENT)
	public interface CaptionBasedToString<T> {
		Component toString(Component component, T object);
	}

	@Environment(EnvType.CLIENT)
	public record ClampingLazyMaxIntRange(int minInclusive, IntSupplier maxSupplier, int encodableMaxInclusive)
		implements OptionInstance.IntRangeBase,
		OptionInstance.SliderableOrCyclableValueSet<Integer> {
		public Optional<Integer> validateValue(Integer integer) {
			return Optional.of(Mth.clamp(integer, this.minInclusive(), this.maxInclusive()));
		}

		@Override
		public int maxInclusive() {
			return this.maxSupplier.getAsInt();
		}

		@Override
		public Codec<Integer> codec() {
			return Codec.INT
				.validate(
					integer -> {
						int i = this.encodableMaxInclusive + 1;
						return integer.compareTo(this.minInclusive) >= 0 && integer.compareTo(i) <= 0
							? DataResult.success(integer)
							: DataResult.error(() -> "Value " + integer + " outside of range [" + this.minInclusive + ":" + i + "]", integer);
					}
				);
		}

		@Override
		public boolean createCycleButton() {
			return true;
		}

		@Override
		public CycleButton.ValueListSupplier<Integer> valueListSupplier() {
			return CycleButton.ValueListSupplier.create(IntStream.range(this.minInclusive, this.maxInclusive() + 1).boxed().toList());
		}
	}

	@Environment(EnvType.CLIENT)
	interface CycleableValueSet<T> extends OptionInstance.ValueSet<T> {
		CycleButton.ValueListSupplier<T> valueListSupplier();

		default OptionInstance.CycleableValueSet.ValueSetter<T> valueSetter() {
			return OptionInstance::set;
		}

		@Override
		default Function<OptionInstance<T>, AbstractWidget> createButton(
			OptionInstance.TooltipSupplier<T> tooltipSupplier, Options options, int i, int j, int k, Consumer<T> consumer
		) {
			return optionInstance -> CycleButton.<T>builder(optionInstance.toString, optionInstance::get)
				.withValues(this.valueListSupplier())
				.withTooltip(tooltipSupplier)
				.create(i, j, k, 20, optionInstance.caption, (cycleButton, object) -> {
					this.valueSetter().set(optionInstance, object);
					options.save();
					consumer.accept(object);
				});
		}

		@Environment(EnvType.CLIENT)
		public interface ValueSetter<T> {
			void set(OptionInstance<T> optionInstance, T object);
		}
	}

	@Environment(EnvType.CLIENT)
	public record Enum<T>(List<T> values, Codec<T> codec) implements OptionInstance.CycleableValueSet<T> {
		@Override
		public Optional<T> validateValue(T object) {
			return this.values.contains(object) ? Optional.of(object) : Optional.empty();
		}

		@Override
		public CycleButton.ValueListSupplier<T> valueListSupplier() {
			return CycleButton.ValueListSupplier.create(this.values);
		}
	}

	@Environment(EnvType.CLIENT)
	public record IntRange(int minInclusive, int maxInclusive, boolean applyValueImmediately) implements OptionInstance.IntRangeBase {
		public IntRange(int i, int j) {
			this(i, j, true);
		}

		public Optional<Integer> validateValue(Integer integer) {
			return integer.compareTo(this.minInclusive()) >= 0 && integer.compareTo(this.maxInclusive()) <= 0 ? Optional.of(integer) : Optional.empty();
		}

		@Override
		public Codec<Integer> codec() {
			return Codec.intRange(this.minInclusive, this.maxInclusive + 1);
		}
	}

	@Environment(EnvType.CLIENT)
	interface IntRangeBase extends OptionInstance.SliderableValueSet<Integer> {
		int minInclusive();

		int maxInclusive();

		default Optional<Integer> next(Integer integer) {
			return Optional.of(integer + 1);
		}

		default Optional<Integer> previous(Integer integer) {
			return Optional.of(integer - 1);
		}

		default double toSliderValue(Integer integer) {
			if (integer == this.minInclusive()) {
				return 0.0;
			} else {
				return integer == this.maxInclusive() ? 1.0 : Mth.map(integer.intValue() + 0.5, this.minInclusive(), this.maxInclusive() + 1.0, 0.0, 1.0);
			}
		}

		default Integer fromSliderValue(double d) {
			if (d >= 1.0) {
				d = 0.99999F;
			}

			return Mth.floor(Mth.map(d, 0.0, 1.0, this.minInclusive(), this.maxInclusive() + 1.0));
		}

		default <R> OptionInstance.SliderableValueSet<R> xmap(IntFunction<? extends R> intFunction, ToIntFunction<? super R> toIntFunction, boolean bl) {
			return new OptionInstance.SliderableValueSet<R>() {
				@Override
				public Optional<R> validateValue(R object) {
					return IntRangeBase.this.validateValue(toIntFunction.applyAsInt(object)).map(intFunction::apply);
				}

				@Override
				public double toSliderValue(R object) {
					return IntRangeBase.this.toSliderValue(toIntFunction.applyAsInt(object));
				}

				@Override
				public Optional<R> next(R object) {
					if (!bl) {
						return Optional.empty();
					} else {
						int i = toIntFunction.applyAsInt(object);
						return Optional.of(intFunction.apply((Integer)IntRangeBase.this.validateValue(i + 1).orElse(i)));
					}
				}

				@Override
				public Optional<R> previous(R object) {
					if (!bl) {
						return Optional.empty();
					} else {
						int i = toIntFunction.applyAsInt(object);
						return Optional.of(intFunction.apply((Integer)IntRangeBase.this.validateValue(i - 1).orElse(i)));
					}
				}

				@Override
				public R fromSliderValue(double d) {
					return (R)intFunction.apply(IntRangeBase.this.fromSliderValue(d));
				}

				@Override
				public Codec<R> codec() {
					return IntRangeBase.this.codec().xmap(intFunction::apply, toIntFunction::applyAsInt);
				}
			};
		}
	}

	@Environment(EnvType.CLIENT)
	public record LazyEnum<T>(Supplier<List<T>> values, Function<T, Optional<T>> validateValue, Codec<T> codec) implements OptionInstance.CycleableValueSet<T> {
		@Override
		public Optional<T> validateValue(T object) {
			return (Optional<T>)this.validateValue.apply(object);
		}

		@Override
		public CycleButton.ValueListSupplier<T> valueListSupplier() {
			return CycleButton.ValueListSupplier.create((Collection<T>)this.values.get());
		}
	}

	@Environment(EnvType.CLIENT)
	public static final class OptionInstanceSliderButton<N> extends AbstractOptionSliderButton implements ResettableOptionWidget {
		private final OptionInstance<N> instance;
		private final OptionInstance.SliderableValueSet<N> values;
		private final OptionInstance.TooltipSupplier<N> tooltipSupplier;
		private final Consumer<N> onValueChanged;
		@Nullable
		private Long delayedApplyAt;
		private final boolean applyValueImmediately;

		OptionInstanceSliderButton(
			Options options,
			int i,
			int j,
			int k,
			int l,
			OptionInstance<N> optionInstance,
			OptionInstance.SliderableValueSet<N> sliderableValueSet,
			OptionInstance.TooltipSupplier<N> tooltipSupplier,
			Consumer<N> consumer,
			boolean bl
		) {
			super(options, i, j, k, l, sliderableValueSet.toSliderValue(optionInstance.get()));
			this.instance = optionInstance;
			this.values = sliderableValueSet;
			this.tooltipSupplier = tooltipSupplier;
			this.onValueChanged = consumer;
			this.applyValueImmediately = bl;
			this.updateMessage();
		}

		@Override
		protected void updateMessage() {
			this.setMessage((Component)this.instance.toString.apply(this.values.fromSliderValue(this.value)));
			this.setTooltip(this.tooltipSupplier.apply(this.values.fromSliderValue(this.value)));
		}

		@Override
		protected void applyValue() {
			if (this.applyValueImmediately) {
				this.applyUnsavedValue();
			} else {
				this.delayedApplyAt = Util.getMillis() + 600L;
			}
		}

		public void applyUnsavedValue() {
			N object = this.values.fromSliderValue(this.value);
			if (!Objects.equals(object, this.instance.get())) {
				this.instance.set(object);
				this.onValueChanged.accept(this.instance.get());
			}
		}

		@Override
		public void resetValue() {
			if (this.value != this.values.toSliderValue(this.instance.get())) {
				this.value = this.values.toSliderValue(this.instance.get());
				this.delayedApplyAt = null;
				this.updateMessage();
			}
		}

		@Override
		public void renderWidget(GuiGraphics guiGraphics, int i, int j, float f) {
			super.renderWidget(guiGraphics, i, j, f);
			if (this.delayedApplyAt != null && Util.getMillis() >= this.delayedApplyAt) {
				this.delayedApplyAt = null;
				this.applyUnsavedValue();
				this.resetValue();
			}
		}

		@Override
		public void onRelease(MouseButtonEvent mouseButtonEvent) {
			super.onRelease(mouseButtonEvent);
			if (this.applyValueImmediately) {
				this.resetValue();
			}
		}

		@Override
		public boolean keyPressed(KeyEvent keyEvent) {
			if (keyEvent.isSelection()) {
				this.canChangeValue = !this.canChangeValue;
				return true;
			} else {
				if (this.canChangeValue) {
					boolean bl = keyEvent.isLeft();
					boolean bl2 = keyEvent.isRight();
					if (bl) {
						Optional<N> optional = this.values.previous(this.values.fromSliderValue(this.value));
						if (optional.isPresent()) {
							this.setValue(this.values.toSliderValue((N)optional.get()));
							return true;
						}
					}

					if (bl2) {
						Optional<N> optional = this.values.next(this.values.fromSliderValue(this.value));
						if (optional.isPresent()) {
							this.setValue(this.values.toSliderValue((N)optional.get()));
							return true;
						}
					}

					if (bl || bl2) {
						float f = bl ? -1.0F : 1.0F;
						this.setValue(this.value + f / (this.width - 8));
						return true;
					}
				}

				return false;
			}
		}
	}

	@Environment(EnvType.CLIENT)
	public record SliderableEnum<T>(List<T> values, Codec<T> codec) implements OptionInstance.SliderableValueSet<T> {
		@Override
		public double toSliderValue(T object) {
			if (object == this.values.getFirst()) {
				return 0.0;
			} else {
				return object == this.values.getLast() ? 1.0 : Mth.map(this.values.indexOf(object), 0.0, this.values.size() - 1, 0.0, 1.0);
			}
		}

		@Override
		public Optional<T> next(T object) {
			int i = this.values.indexOf(object);
			int j = Mth.clamp(i + 1, 0, this.values.size() - 1);
			return Optional.of(this.values.get(j));
		}

		@Override
		public Optional<T> previous(T object) {
			int i = this.values.indexOf(object);
			int j = Mth.clamp(i - 1, 0, this.values.size() - 1);
			return Optional.of(this.values.get(j));
		}

		@Override
		public T fromSliderValue(double d) {
			if (d >= 1.0) {
				d = 0.99999F;
			}

			int i = Mth.floor(Mth.map(d, 0.0, 1.0, 0.0, this.values.size()));
			return (T)this.values.get(Mth.clamp(i, 0, this.values.size() - 1));
		}

		@Override
		public Optional<T> validateValue(T object) {
			int i = this.values.indexOf(object);
			return i > -1 ? Optional.of(object) : Optional.empty();
		}
	}

	@Environment(EnvType.CLIENT)
	interface SliderableOrCyclableValueSet<T> extends OptionInstance.CycleableValueSet<T>, OptionInstance.SliderableValueSet<T> {
		boolean createCycleButton();

		@Override
		default Function<OptionInstance<T>, AbstractWidget> createButton(
			OptionInstance.TooltipSupplier<T> tooltipSupplier, Options options, int i, int j, int k, Consumer<T> consumer
		) {
			return this.createCycleButton()
				? OptionInstance.CycleableValueSet.super.createButton(tooltipSupplier, options, i, j, k, consumer)
				: OptionInstance.SliderableValueSet.super.createButton(tooltipSupplier, options, i, j, k, consumer);
		}
	}

	@Environment(EnvType.CLIENT)
	interface SliderableValueSet<T> extends OptionInstance.ValueSet<T> {
		double toSliderValue(T object);

		default Optional<T> next(T object) {
			return Optional.empty();
		}

		default Optional<T> previous(T object) {
			return Optional.empty();
		}

		T fromSliderValue(double d);

		default boolean applyValueImmediately() {
			return true;
		}

		@Override
		default Function<OptionInstance<T>, AbstractWidget> createButton(
			OptionInstance.TooltipSupplier<T> tooltipSupplier, Options options, int i, int j, int k, Consumer<T> consumer
		) {
			return optionInstance -> new OptionInstance.OptionInstanceSliderButton<>(
				options, i, j, k, 20, optionInstance, this, tooltipSupplier, consumer, this.applyValueImmediately()
			);
		}
	}

	@FunctionalInterface
	@Environment(EnvType.CLIENT)
	public interface TooltipSupplier<T> {
		@Nullable
		Tooltip apply(T object);
	}

	@Environment(EnvType.CLIENT)
	public static enum UnitDouble implements OptionInstance.SliderableValueSet<Double> {
		INSTANCE;

		public Optional<Double> validateValue(Double double_) {
			return double_ >= 0.0 && double_ <= 1.0 ? Optional.of(double_) : Optional.empty();
		}

		public double toSliderValue(Double double_) {
			return double_;
		}

		public Double fromSliderValue(double d) {
			return d;
		}

		public <R> OptionInstance.SliderableValueSet<R> xmap(DoubleFunction<? extends R> doubleFunction, ToDoubleFunction<? super R> toDoubleFunction) {
			return new OptionInstance.SliderableValueSet<R>() {
				@Override
				public Optional<R> validateValue(R object) {
					return UnitDouble.this.validateValue(toDoubleFunction.applyAsDouble(object)).map(doubleFunction::apply);
				}

				@Override
				public double toSliderValue(R object) {
					return UnitDouble.this.toSliderValue(toDoubleFunction.applyAsDouble(object));
				}

				@Override
				public R fromSliderValue(double d) {
					return (R)doubleFunction.apply(UnitDouble.this.fromSliderValue(d));
				}

				@Override
				public Codec<R> codec() {
					return UnitDouble.this.codec().xmap(doubleFunction::apply, toDoubleFunction::applyAsDouble);
				}
			};
		}

		@Override
		public Codec<Double> codec() {
			return Codec.withAlternative(Codec.doubleRange(0.0, 1.0), Codec.BOOL, boolean_ -> boolean_ ? 1.0 : 0.0);
		}
	}

	@Environment(EnvType.CLIENT)
	interface ValueSet<T> {
		Function<OptionInstance<T>, AbstractWidget> createButton(
			OptionInstance.TooltipSupplier<T> tooltipSupplier, Options options, int i, int j, int k, Consumer<T> consumer
		);

		Optional<T> validateValue(T object);

		Codec<T> codec();
	}
}
