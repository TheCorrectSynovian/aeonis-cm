@NullMarked
@Environment(EnvType.CLIENT)
package com.mojang.realmsclient.client.worldupload;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.NullMarked;
