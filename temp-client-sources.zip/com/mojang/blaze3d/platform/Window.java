package com.mojang.blaze3d.platform;

import com.mojang.blaze3d.TracyFrameCapture;
import com.mojang.blaze3d.platform.cursor.CursorType;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.function.BiConsumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.CrashReport;
import net.minecraft.CrashReportCategory;
import net.minecraft.ReportedException;
import net.minecraft.client.main.SilentInitException;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.resources.IoSupplier;
import org.jspecify.annotations.Nullable;
import org.lwjgl.PointerBuffer;
import org.lwjgl.glfw.Callbacks;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.glfw.GLFWWindowCloseCallback;
import org.lwjgl.glfw.GLFWImage.Buffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import org.lwjgl.util.tinyfd.TinyFileDialogs;
import org.slf4j.Logger;

@Environment(EnvType.CLIENT)
public final class Window implements AutoCloseable {
	private static final Logger LOGGER = LogUtils.getLogger();
	public static final int BASE_WIDTH = 320;
	public static final int BASE_HEIGHT = 240;
	private final GLFWErrorCallback defaultErrorCallback = GLFWErrorCallback.create(this::defaultErrorCallback);
	private final WindowEventHandler eventHandler;
	private final ScreenManager screenManager;
	private final long handle;
	private int windowedX;
	private int windowedY;
	private int windowedWidth;
	private int windowedHeight;
	private Optional<VideoMode> preferredFullscreenVideoMode;
	private boolean fullscreen;
	private boolean actuallyFullscreen;
	private int x;
	private int y;
	private int width;
	private int height;
	private int framebufferWidth;
	private int framebufferHeight;
	private int guiScaledWidth;
	private int guiScaledHeight;
	private int guiScale;
	private String errorSection = "";
	private boolean dirty;
	private boolean vsync;
	private boolean iconified;
	private boolean minimized;
	private boolean allowCursorChanges;
	private CursorType currentCursor = CursorType.DEFAULT;

	public Window(WindowEventHandler windowEventHandler, ScreenManager screenManager, DisplayData displayData, @Nullable String string, String string2) {
		this.screenManager = screenManager;
		this.setBootErrorCallback();
		this.setErrorSection("Pre startup");
		this.eventHandler = windowEventHandler;
		Optional<VideoMode> optional = VideoMode.read(string);
		if (optional.isPresent()) {
			this.preferredFullscreenVideoMode = optional;
		} else if (displayData.fullscreenWidth().isPresent() && displayData.fullscreenHeight().isPresent()) {
			this.preferredFullscreenVideoMode = Optional.of(
				new VideoMode(displayData.fullscreenWidth().getAsInt(), displayData.fullscreenHeight().getAsInt(), 8, 8, 8, 60)
			);
		} else {
			this.preferredFullscreenVideoMode = Optional.empty();
		}

		this.actuallyFullscreen = this.fullscreen = displayData.isFullscreen();
		Monitor monitor = screenManager.getMonitor(GLFW.glfwGetPrimaryMonitor());
		this.windowedWidth = this.width = Math.max(displayData.width(), 1);
		this.windowedHeight = this.height = Math.max(displayData.height(), 1);
		GLFW.glfwDefaultWindowHints();
		GLFW.glfwWindowHint(139265, 196609);
		GLFW.glfwWindowHint(139275, 221185);
		GLFW.glfwWindowHint(139266, 3);
		GLFW.glfwWindowHint(139267, 3);
		GLFW.glfwWindowHint(139272, 204801);
		GLFW.glfwWindowHint(139270, 1);
		this.handle = GLFW.glfwCreateWindow(this.width, this.height, string2, this.fullscreen && monitor != null ? monitor.getMonitor() : 0L, 0L);
		if (monitor != null) {
			VideoMode videoMode = monitor.getPreferredVidMode(this.fullscreen ? this.preferredFullscreenVideoMode : Optional.empty());
			this.windowedX = this.x = monitor.getX() + videoMode.getWidth() / 2 - this.width / 2;
			this.windowedY = this.y = monitor.getY() + videoMode.getHeight() / 2 - this.height / 2;
		} else {
			int[] is = new int[1];
			int[] js = new int[1];
			GLFW.glfwGetWindowPos(this.handle, is, js);
			this.windowedX = this.x = is[0];
			this.windowedY = this.y = js[0];
		}

		this.setMode();
		this.refreshFramebufferSize();
		GLFW.glfwSetFramebufferSizeCallback(this.handle, this::onFramebufferResize);
		GLFW.glfwSetWindowPosCallback(this.handle, this::onMove);
		GLFW.glfwSetWindowSizeCallback(this.handle, this::onResize);
		GLFW.glfwSetWindowFocusCallback(this.handle, this::onFocus);
		GLFW.glfwSetCursorEnterCallback(this.handle, this::onEnter);
		GLFW.glfwSetWindowIconifyCallback(this.handle, this::onIconify);
	}

	public static String getPlatform() {
		int i = GLFW.glfwGetPlatform();

		return switch (i) {
			case 0 -> "<error>";
			case 393217 -> "win32";
			case 393218 -> "cocoa";
			case 393219 -> "wayland";
			case 393220 -> "x11";
			case 393221 -> "null";
			default -> String.format(Locale.ROOT, "unknown (%08X)", i);
		};
	}

	public int getRefreshRate() {
		RenderSystem.assertOnRenderThread();
		return GLX._getRefreshRate(this);
	}

	public boolean shouldClose() {
		return GLX._shouldClose(this);
	}

	public static void checkGlfwError(BiConsumer<Integer, String> biConsumer) {
		try (MemoryStack memoryStack = MemoryStack.stackPush()) {
			PointerBuffer pointerBuffer = memoryStack.mallocPointer(1);
			int i = GLFW.glfwGetError(pointerBuffer);
			if (i != 0) {
				long l = pointerBuffer.get();
				String string = l == 0L ? "" : MemoryUtil.memUTF8(l);
				biConsumer.accept(i, string);
			}
		}
	}

	public void setIcon(PackResources packResources, IconSet iconSet) throws IOException {
		int i = GLFW.glfwGetPlatform();
		switch (i) {
			case 393217:
			case 393220:
				List<IoSupplier<InputStream>> list = iconSet.getStandardIcons(packResources);
				List<ByteBuffer> list2 = new ArrayList(list.size());

				try (MemoryStack memoryStack = MemoryStack.stackPush()) {
					Buffer buffer = GLFWImage.malloc(list.size(), memoryStack);

					for (int j = 0; j < list.size(); j++) {
						try (NativeImage nativeImage = NativeImage.read((InputStream)((IoSupplier)list.get(j)).get())) {
							ByteBuffer byteBuffer = MemoryUtil.memAlloc(nativeImage.getWidth() * nativeImage.getHeight() * 4);
							list2.add(byteBuffer);
							byteBuffer.asIntBuffer().put(nativeImage.getPixelsABGR());
							buffer.position(j);
							buffer.width(nativeImage.getWidth());
							buffer.height(nativeImage.getHeight());
							buffer.pixels(byteBuffer);
						}
					}

					GLFW.glfwSetWindowIcon(this.handle, buffer.position(0));
					break;
				} finally {
					list2.forEach(MemoryUtil::memFree);
				}
			case 393218:
				MacosUtil.loadIcon(iconSet.getMacIcon(packResources));
			case 393219:
			case 393221:
				break;
			default:
				LOGGER.warn("Not setting icon for unrecognized platform: {}", i);
		}
	}

	public void setErrorSection(String string) {
		this.errorSection = string;
	}

	private void setBootErrorCallback() {
		GLFW.glfwSetErrorCallback(Window::bootCrash);
	}

	private static void bootCrash(int i, long l) {
		String string = "GLFW error " + i + ": " + MemoryUtil.memUTF8(l);
		TinyFileDialogs.tinyfd_messageBox(
			"Minecraft", string + ".\n\nPlease make sure you have up-to-date drivers (see aka.ms/mcdriver for instructions).", "ok", "error", false
		);
		throw new Window.WindowInitFailed(string);
	}

	public void defaultErrorCallback(int i, long l) {
		RenderSystem.assertOnRenderThread();
		String string = MemoryUtil.memUTF8(l);
		LOGGER.error("########## GL ERROR ##########");
		LOGGER.error("@ {}", this.errorSection);
		LOGGER.error("{}: {}", i, string);
	}

	public void setDefaultErrorCallback() {
		GLFWErrorCallback gLFWErrorCallback = GLFW.glfwSetErrorCallback(this.defaultErrorCallback);
		if (gLFWErrorCallback != null) {
			gLFWErrorCallback.free();
		}
	}

	public void updateVsync(boolean bl) {
		RenderSystem.assertOnRenderThread();
		this.vsync = bl;
		GLFW.glfwSwapInterval(bl ? 1 : 0);
	}

	public void close() {
		RenderSystem.assertOnRenderThread();
		Callbacks.glfwFreeCallbacks(this.handle);
		this.defaultErrorCallback.close();
		GLFW.glfwDestroyWindow(this.handle);
		GLFW.glfwTerminate();
	}

	private void onMove(long l, int i, int j) {
		this.x = i;
		this.y = j;
	}

	private void onFramebufferResize(long l, int i, int j) {
		if (l == this.handle) {
			int k = this.getWidth();
			int m = this.getHeight();
			if (i != 0 && j != 0) {
				this.minimized = false;
				this.framebufferWidth = i;
				this.framebufferHeight = j;
				if (this.getWidth() != k || this.getHeight() != m) {
					try {
						this.eventHandler.resizeDisplay();
					} catch (Exception var10) {
						CrashReport crashReport = CrashReport.forThrowable(var10, "Window resize");
						CrashReportCategory crashReportCategory = crashReport.addCategory("Window Dimensions");
						crashReportCategory.setDetail("Old", k + "x" + m);
						crashReportCategory.setDetail("New", i + "x" + j);
						throw new ReportedException(crashReport);
					}
				}
			} else {
				this.minimized = true;
			}
		}
	}

	private void refreshFramebufferSize() {
		int[] is = new int[1];
		int[] js = new int[1];
		GLFW.glfwGetFramebufferSize(this.handle, is, js);
		this.framebufferWidth = is[0] > 0 ? is[0] : 1;
		this.framebufferHeight = js[0] > 0 ? js[0] : 1;
	}

	private void onResize(long l, int i, int j) {
		this.width = i;
		this.height = j;
	}

	private void onFocus(long l, boolean bl) {
		if (l == this.handle) {
			this.eventHandler.setWindowActive(bl);
		}
	}

	private void onEnter(long l, boolean bl) {
		if (bl) {
			this.eventHandler.cursorEntered();
		}
	}

	private void onIconify(long l, boolean bl) {
		this.iconified = bl;
	}

	public void updateDisplay(@Nullable TracyFrameCapture tracyFrameCapture) {
		RenderSystem.flipFrame(this, tracyFrameCapture);
		if (this.fullscreen != this.actuallyFullscreen) {
			this.actuallyFullscreen = this.fullscreen;
			this.updateFullscreen(this.vsync, tracyFrameCapture);
		}
	}

	public Optional<VideoMode> getPreferredFullscreenVideoMode() {
		return this.preferredFullscreenVideoMode;
	}

	public void setPreferredFullscreenVideoMode(Optional<VideoMode> optional) {
		boolean bl = !optional.equals(this.preferredFullscreenVideoMode);
		this.preferredFullscreenVideoMode = optional;
		if (bl) {
			this.dirty = true;
		}
	}

	public void changeFullscreenVideoMode() {
		if (this.fullscreen && this.dirty) {
			this.dirty = false;
			this.setMode();
			this.eventHandler.resizeDisplay();
		}
	}

	private void setMode() {
		boolean bl = GLFW.glfwGetWindowMonitor(this.handle) != 0L;
		if (this.fullscreen) {
			Monitor monitor = this.screenManager.findBestMonitor(this);
			if (monitor == null) {
				LOGGER.warn("Failed to find suitable monitor for fullscreen mode");
				this.fullscreen = false;
			} else {
				if (MacosUtil.IS_MACOS) {
					MacosUtil.exitNativeFullscreen(this);
				}

				VideoMode videoMode = monitor.getPreferredVidMode(this.preferredFullscreenVideoMode);
				if (!bl) {
					this.windowedX = this.x;
					this.windowedY = this.y;
					this.windowedWidth = this.width;
					this.windowedHeight = this.height;
				}

				this.x = 0;
				this.y = 0;
				this.width = videoMode.getWidth();
				this.height = videoMode.getHeight();
				GLFW.glfwSetWindowMonitor(this.handle, monitor.getMonitor(), this.x, this.y, this.width, this.height, videoMode.getRefreshRate());
				if (MacosUtil.IS_MACOS) {
					MacosUtil.clearResizableBit(this);
				}
			}
		} else {
			this.x = this.windowedX;
			this.y = this.windowedY;
			this.width = this.windowedWidth;
			this.height = this.windowedHeight;
			GLFW.glfwSetWindowMonitor(this.handle, 0L, this.x, this.y, this.width, this.height, -1);
		}
	}

	public void toggleFullScreen() {
		this.fullscreen = !this.fullscreen;
	}

	public void setWindowed(int i, int j) {
		this.windowedWidth = i;
		this.windowedHeight = j;
		this.fullscreen = false;
		this.setMode();
	}

	private void updateFullscreen(boolean bl, @Nullable TracyFrameCapture tracyFrameCapture) {
		RenderSystem.assertOnRenderThread();

		try {
			this.setMode();
			this.eventHandler.resizeDisplay();
			this.updateVsync(bl);
			this.updateDisplay(tracyFrameCapture);
		} catch (Exception var4) {
			LOGGER.error("Couldn't toggle fullscreen", (Throwable)var4);
		}
	}

	public int calculateScale(int i, boolean bl) {
		int j = 1;

		while (j != i && j < this.framebufferWidth && j < this.framebufferHeight && this.framebufferWidth / (j + 1) >= 320 && this.framebufferHeight / (j + 1) >= 240) {
			j++;
		}

		if (bl && j % 2 != 0) {
			j++;
		}

		return j;
	}

	public void setGuiScale(int i) {
		this.guiScale = i;
		double d = i;
		int j = (int)(this.framebufferWidth / d);
		this.guiScaledWidth = this.framebufferWidth / d > j ? j + 1 : j;
		int k = (int)(this.framebufferHeight / d);
		this.guiScaledHeight = this.framebufferHeight / d > k ? k + 1 : k;
	}

	public void setTitle(String string) {
		GLFW.glfwSetWindowTitle(this.handle, string);
	}

	public long handle() {
		return this.handle;
	}

	public boolean isFullscreen() {
		return this.fullscreen;
	}

	public boolean isIconified() {
		return this.iconified;
	}

	public int getWidth() {
		return this.framebufferWidth;
	}

	public int getHeight() {
		return this.framebufferHeight;
	}

	public void setWidth(int i) {
		this.framebufferWidth = i;
	}

	public void setHeight(int i) {
		this.framebufferHeight = i;
	}

	public int getScreenWidth() {
		return this.width;
	}

	public int getScreenHeight() {
		return this.height;
	}

	public int getGuiScaledWidth() {
		return this.guiScaledWidth;
	}

	public int getGuiScaledHeight() {
		return this.guiScaledHeight;
	}

	public int getX() {
		return this.x;
	}

	public int getY() {
		return this.y;
	}

	public int getGuiScale() {
		return this.guiScale;
	}

	@Nullable
	public Monitor findBestMonitor() {
		return this.screenManager.findBestMonitor(this);
	}

	public void updateRawMouseInput(boolean bl) {
		InputConstants.updateRawMouseInput(this, bl);
	}

	public void setWindowCloseCallback(Runnable runnable) {
		GLFWWindowCloseCallback gLFWWindowCloseCallback = GLFW.glfwSetWindowCloseCallback(this.handle, l -> runnable.run());
		if (gLFWWindowCloseCallback != null) {
			gLFWWindowCloseCallback.free();
		}
	}

	public boolean isMinimized() {
		return this.minimized;
	}

	public void setAllowCursorChanges(boolean bl) {
		this.allowCursorChanges = bl;
	}

	public void selectCursor(CursorType cursorType) {
		CursorType cursorType2 = this.allowCursorChanges ? cursorType : CursorType.DEFAULT;
		if (this.currentCursor != cursorType2) {
			this.currentCursor = cursorType2;
			cursorType2.select(this);
		}
	}

	public float getAppropriateLineWidth() {
		return Math.max(2.5F, this.getWidth() / 1920.0F * 2.5F);
	}

	@Environment(EnvType.CLIENT)
	public static class WindowInitFailed extends SilentInitException {
		WindowInitFailed(String string) {
			super(string);
		}
	}
}
