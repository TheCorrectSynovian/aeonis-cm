@NullMarked
@Environment(EnvType.CLIENT)
package com.mojang.blaze3d.resource;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jspecify.annotations.NullMarked;
