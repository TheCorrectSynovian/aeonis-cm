1.4.3.4:

This update didn't add anything; it focused on fixing bugs and shortcomings in the game.
A few bugs fixed.
Fixed some bugs with animated creatures
There have been changes made to bosses, such as damage resistance.
Reduced the power of the Radioactive Warden's sonic boom.
The fillingness of the meals has been changed.
Translation errors have been corrected.
Fixed several bugs that were preventing spawners from working.
The missing crafting element for the slime block has been added, and the transparency issue has been resolved.
Many swords, weapons, and similar tools that are missing enchantments can now have enchantments applied.
Bad item designs have been fixed.
Detailed instructions showing how to craft the items inside have been added to the Dispenser Crafter and Advanced Furnace guides.
It now gives a more accurate warning if the Geckolib mod is missing.
 

1.4.3.3:

Arda's Sculks was translated into Brazilian Portuguese by Iago Emanuel.

 

1.4.3.2:

Bugfix
 

1.4.3.1:

Deficiencies in wood have been completed.
Updated the Sculk Enderman's texture and model and fixed the animation bug.
Some textures have been renewed.
The Sculkerite Long Sword was added to the game.
Half steps and stairs were added to some blocks.
Added new Sculk Arms.
Boss durability has been reduced and Sculk arm strength has been reduced.
Added animation to Sculk Bow.
 

1.4.3:

A new boss, the Shadow Hunter, has been added to the game: The Shadow Hunter is a character with low health and high speed. If you try to escape, he will teleport and kick you.
With the addition of Shadow Hunter, a new boss location has been added.
Many decorative blocks have been added in this update.
The skeleton's bow now appears 3D.
and a few bug fixes.
 

1.4.2.1:

 This is a very minor update that includes minor texture changes, animation updates, and a few bug fixes.
 

1.4.2:

Improved creeper animation.
It is no longer necessary to break sculk vines to open the Ancient Portal.
The textures of the Sculk decoration blocks have been updated.
A new layer level has been added that occurs on negative floors, and new mines and plants specific to this layer level have been added.
Added new biome: radioactive balsa forest and new tree species.
Added new machine, Deepslate Crafting Dispenser.
New decoration blocks have been added.
New boss radioactive warden added.
Finally, parts like the radioactive Sculk arm and Sculkerite hammer were added.
 

1.4.1.1:

Optimized the Sculk Golem dungeon.
Translation errors in Turkish language have been corrected.
Reduced the knockback of Sculk Golem and Sculk Creaking creatures.
The sculk portal that opens the entrance to the Sculk Golem Dungeon no longer freezes the game and is faster.
The cost of some crafts has been reduced.
Reduced the damage of the Sculk Golem.
And a few bug fixes.
 

1.4.1:

textures have been improved.
The texture of the portal has been made more similar to the cover of the mod.
New Warden Items and Warden Armors have been added.
Two new special powers have been added to the Warden armor, one of which is Warden feelings and the other is sonic boom.
Significantly reduced lag in the Sculk Golem Dungeon.
We can now make tools from any type of wood.
The Sculk Crystal in the game has been replaced with the Deep Dark Upgrade Template, and the Sculk Crystal has been added to the game as a different gem.
Summon eggs now have unique textures.
And a few bug fixes.
