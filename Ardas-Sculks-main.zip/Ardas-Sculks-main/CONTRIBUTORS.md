# Contributors

I would like to express my gratitude to the following individuals for their significant contributions to this project:

- **[Lyka]**: He tested the mod, found many bugs, and created great videos to promote the project.
- **[Warex]**: He gave me the idea to create this mod, tested it, and helped me find various issues during development.

Thank you for your support in making this project better.
